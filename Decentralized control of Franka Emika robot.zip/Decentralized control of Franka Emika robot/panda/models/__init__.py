import os
from .world import MujocoWorldBase

assets_root = os.path.join(os.path.dirname(__file__), "assets")
